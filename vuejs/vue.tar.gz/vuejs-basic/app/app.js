(function(){
	var app = new Vue({
		el: "#vueapp",
		data: {
			message: "Hello, world of Vue",
			mtitle: "le title du hello world",
			toReverse: "cliquez-moi pour m'inverser",
			todos: [
				{text: "un premier todo"},
				{text: "un deuxième todo"},
				{text: "un troisième todo"}
			]
		},
		methods: {
			reverseMessage: function() {
				this.toReverse = this.toReverse.split('').reverse().join('');
			}
		}
	});
})();