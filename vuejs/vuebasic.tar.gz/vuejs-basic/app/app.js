(function(){
	Vue.component('todo-item', {
		props: ["todos"],
		template: '<div><ul><li v-for="item in todos">{{ item.done }} - {{ item.text }}</li></ul></div>'
	});

	var app = new Vue({
		el: "#vueapp",
		data: {
			message: "Hello, world of Vue",
			mtitle: "le title du hello world",
			toReverse: "cliquez-moi pour m'inverser",
			todos: [
				{text: "un premier todo", done: 0},
				{text: "un deuxième todo", done: 0},
				{text: "un troisième todo", done: 0}
			]
		},
		methods: {
			reverseMessage: function() {
				this.toReverse = this.toReverse.split('').reverse().join('');
			}
		}
	});
})();