#vuejs - premiers pas

##répertoires
###assets/css
pure.io
normalize.css
###assets/lib/vuejs
deux fichiers ici: 
vue.js 			à utiliser en développement
vue.min.js 		à utiliser en production
d'après le site de vuejs: "Don’t use the minified version during development. You will miss out all the nice warnings for common mistakes!"