#ajs-basic - basic angular app
contains some basic things:
- filter - ucfirst text
- service - get some datas to fill basic texts on <header> and <footer>
- router - with ui router - two very simple pages to show how to use the router
- directive - to write something in the body of the pages

- normalize.css
- pureio.css 
