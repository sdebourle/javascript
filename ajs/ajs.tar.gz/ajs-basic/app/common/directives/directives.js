(function() {
    angular
        .module('baseDirectives',['baseServices'])
        .directive('page1Directive', ['dataBaseApp', page1Directive]);

    function page1Directive(dba) {
		return {
			scope: {},
			restrict: 'A',
			replace: true,
			transclude: false,
			// une version valide, car 'main' est le controller principal sur index.html
//			template: '<div class="half"><ul><li ng-repeat="elt in main.dataP1"><div>{{elt.txt}}</div><div>{{elt.stxt}}</div></li></ul></div>',
			// version avec lecture du service, injecté dans la directive
			template: '<div class="half"><ul><li ng-repeat="elt in p1d.dataP1"><div>{{elt.txt}}</div><div>{{elt.stxt}}</div></li></ul></div>',
			controller: function() {
				this.dataP1 = dba.p1;
			},
			controllerAs: 'p1d',
			link: function (scope, element, attrs) {
			  // DOM manipulation/events here!
			}
		};    
	}
})();
