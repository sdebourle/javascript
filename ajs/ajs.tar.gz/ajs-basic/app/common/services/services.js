(function() {
    angular
        .module('baseServices', [])
        .factory('dataBaseApp', dataBaseApp)
        .factory('dataParkings', ['$http', dataParkings]);

    // titre et sous-titre de la home page
    function dataBaseApp() {
        dba = {};
        dba.home = {"title": "basic angular js app", "subtitle": "simple basic things to start an angularjs app faster"};
        dba.p1 = [
        	{"txt": "ligne 1", "stxt": "sous la ligne 1"},
        	{"txt": "ligne 2", "stxt": "sous la ligne 2"},
        	{"txt": "ligne 3", "stxt": "sous la ligne 3"},
        ];
        return dba;
    }

    // exemple d'appel ajax en nodejs
    // places de parking disponibles à Nantes
    // /!\ nécessite un serveur en :8080/parkings qui va chercher la réponse de "url"
    function dataParkings($http) {
        var proxy = 'http://localhost:8080/parkings';
        var url = 'http://data.nantes.fr/api/getDisponibiliteParkingsPublics/1.0/39W9VSNCSASEOGV/';
        var dataFile = 'data/data.json';
        var dp = {};
        dp.data = [];
        dp.hello = "Places de parking disponibles à Nantes";
        dp.getData = function(response) {
            angular.copy(response.data.opendata.answer.data.Groupes_Parking.Groupe_Parking, dp.data);
        };
        dp.errorData = function(response) {
            console.log(response);
        };
        var config = {
            'responseType': 'json',
            'params': {'output': 'json'}
        };
        $http.get(proxy, config).then(dp.getData,dp.errorData);

        return dp;
    }
})();
