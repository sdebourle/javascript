(function() {
    angular
        .module('baseFilters',[])
        .filter('ucFirst', ucFirst);

    function ucFirst() {
        return function (input) {
            return (typeof input !== 'undefined' ? input[0].toUpperCase() + input.slice(1).toLowerCase() : '');
        };
    }
})();