(function() {

	var pcomponent = {
    	controller: function(dataBaseApp) {
    		this.dataP1 = dataBaseApp.p1;
    	},
    	controllerAs: "pc",
		template: '<div><ul><li ng-repeat="elt in pc.dataP1"><div>{{elt.txt}}</div><div>{{elt.stxt}}</div></li></ul></div>'
	};

    angular
        .module('baseComponent',['baseServices'])
        .component('pcomponent', pcomponent);
})();
