(function() {
	'use strict';
    angular
        .module('baseApp', ['ui.router', 'baseServices', 'baseFilters', 'baseDirectives', 'baseComponent'])
        .controller('mainController', ['dataBaseApp', mainController])
        .controller('homeController', [homeController])
        .controller('p1Controller', [p1Controller])
    	.config(function($stateProvider, $urlRouterProvider) {
			$urlRouterProvider.otherwise('/home');
            $stateProvider
                .state('home', {
                    url: "/home",
                    controller: "homeController",
                    controllerAs: "home",
                    template: "This is the home page"
                })
                .state('page1', {
                    url: "/page1",
                    controller: "p1Controller",
                    controllerAs: "p1",
                    template: "<div>This is page1</div><div><div page1-directive></div><div page1-directive></div></div><div><pcomponent></pcomponent></div>"
                }); 
    	});

    // ----- controllers
    function mainController(dba) {
    	this.title = dba.home.title;
    	this.subtitle = dba.home.subtitle;
    	this.dataP1 = dba.p1;
    }
    function homeController() {
    	console.log("home controller");
    }
    function p1Controller() {
    	console.log("page1 controller");
    }
})();
